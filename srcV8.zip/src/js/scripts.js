/*!
 * Start Bootstrap - Bare v5.0.2 (https://startbootstrap.com/template/bare)
 * Copyright 2013-2021 Start Bootstrap
 * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-bare/blob/master/LICENSE)
 */
// This file is intentionally blank
// Use this file to add JavaScript to your project

$(document).ready(function() {
    $('.cc-s7-faq-text').on("click", function(event, control) {
        console.log(event);

        $('.cc-s7-faq-text').removeClass("cc-s7-text-heading");
        $('.cc-s7-faq-text').addClass("cc-s7-text-normal");
        $(event.currentTarget).addClass("cc-s7-text-heading");
        var answer = $(event.currentTarget)[0].children[2].innerText;
        var question = $(event.currentTarget)[0].children[1].innerText;
        ($('.faq-answer-conatainer-question')[0]).innerText = question;
        ($('.faq-answer-conatainer-answer')[0]).innerText = answer;

        $('.cc-s7-middle').offset({ top: $(event.currentTarget).offset().top + -10, left: $('.cc-s7-middle').offset().left });
    });
    $('#newsBtnClose').click(function() {
        $('#news').modal('hide');
    });
    $('#youtubeBtnClose').click(function () {
        $('#youtubeModal').modal('hide');
    });
});

var searchTrigger = document.getElementsByClassName("cc-menu-floating-search-trigger")[0];
var toggler = document.getElementsByClassName("cc-desk-menu1-toggler")[0];
var togglerInner = document.getElementsByClassName("cc-desk-menu1-toggler-inner")[0];
var menuOne = document.getElementsByClassName("cc-desk-menu1")[0];
var menuTwo = document.getElementsByClassName("cc-desk-menu2")[0];
var desktopWidgets = document.getElementsByClassName("cc-desktop-widgets")[0];
var mobileWidgets = document.getElementsByClassName("cc-mobile-widgets")[0];
if (mobileWidgets != null && desktopWidgets != null) {
    mobileWidgets.innerHTML = desktopWidgets.innerHTML;
    mobileWidgets.getElementsByClassName("carousel-control-prev")[0].setAttribute("data-bs-target", "#dynamicSidebarSlider2");
    mobileWidgets.getElementsByClassName("carousel-control-next")[0].setAttribute("data-bs-target", "#dynamicSidebarSlider2");
    mobileWidgets.getElementsByClassName("cc-sidebar-slider")[0].id = 'dynamicSidebarSlider2';
}

$('#cc-menu-floating-search-trigger').click(function () {
    $('#cc-menu-floating-search').addClass("cc-float-in");
});

$('#cc-close-search-trigger').click(function () {
    $('#cc-menu-floating-search').removeClass("cc-float-in");
});

var isModalOpen = false;

function myFunction(x) {
    if (x.matches) { // If media query matches
        var inner = document.getElementsByClassName("cc-desk-menu2-left-inner")[0];
        var right = document.getElementsByClassName("cc-desk-menu2-right")[0];
        inner.classList.add("w-100");
        right.style.display = "none";
    } else {
        var inner = document.getElementsByClassName("cc-desk-menu2-left-inner")[0];
        var right = document.getElementsByClassName("cc-desk-menu2-right")[0];
        inner.classList.remove("w-100");
        right.style.display = "flex";
    }
}

function toggleModal() {
    if (isModalOpen == false) {
        toggler.classList.add("btn-close");
        togglerInner.style.display = "none";
        document.getElementById("myModal").style.display = "block";
        isModalOpen = true;
        disableScroll();
    } else {
        toggler.classList.remove("btn-close");
        togglerInner.style.display = "block";
        document.getElementById("myModal").style.display = "none";
        isModalOpen = false;
        enableScroll();
    }
}
var x = window.matchMedia("(max-width: 992px)");
myFunction(x); // Call listener function at run time
x.addListener(myFunction); // Attach listener function on state changes


// call this to Disable
function disableScroll() {
    menuOne.style.position = "fixed";
    menuTwo.style.marginTop = "67px";
}

// call this to Enable
function enableScroll() {
    menuOne.style.position = "relative";
    menuTwo.style.marginTop = "0px";
}